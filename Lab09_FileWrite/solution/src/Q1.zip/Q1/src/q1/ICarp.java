/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package q1;

import java.util.List;

/**
 *
 * @author Le Anh Tuan - CE180905
 */
public interface ICarp {
    int f1(List<Carp> t);
    void f2(List<Carp> t);
    void f3(List<Carp> t);
}
